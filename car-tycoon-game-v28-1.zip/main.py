import pygame
import random
import sys
import time
import pickle
from collections import Counter

# Initialize Pygame
pygame.init()

# Constants
FPS = 50
MONEY_PER_CLICK = 1000
BOX_PRICE = 20000
INVENTORY_SIZE_PER_PAGE = 10
ACHIEVEMENTS_PER_PAGE = 6
TRADE_TICK_INTERVAL = 5  # Time interval for generating new trade offers (in seconds)
BOT_TRADE_INTERVAL = 10  # Time interval for bot trades (in seconds)

# Setup the screen
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
SCREEN_WIDTH, SCREEN_HEIGHT = pygame.display.get_surface().get_size()
clock = pygame.time.Clock()

# Game variables
money = 0
safe_money = 0
inventory = []
safe_inventory = []
current_screen = 'main_menu'
inventory_page = 0
safe_inventory_page = 0
selected_car = None
race_in_progress = False
race_start_time = 0
player_car_pos = 0
opponent_car_pos = 0
opponent_car = None
car_index_page = 0
race_page = 0
races_won = 0
boxes_opened = 0
total_cars_owned = 0
achievement_page = 0
sort_by_speed = False
sort_by_rarity = False
sort_by_price = False
trade_offers = []
next_trade_tick = time.time() + TRADE_TICK_INTERVAL
next_bot_trade_tick = time.time() + BOT_TRADE_INTERVAL
market_page = 0
jackpot_amount = 100000

# Achievements and Quests
achievements = [
    {"name": "First Box", "description": "Open your first box", "completed": False},
    {"name": "Millionaire", "description": "Earn $1,000,000", "completed": False},
    {"name": "Collector", "description": "Collect 10 cars", "completed": False},
    {"name": "Racer", "description": "Win 5 drag races", "completed": False},
    {"name": "High Roller", "description": "Have $10,000,000", "completed": False},
    {"name": "Speed Demon", "description": "Own a car with speed over 250 mph", "completed": False},
    {"name": "Box Master", "description": "Open 50 boxes", "completed": False},
    {"name": "Billionaire", "description": "Have $1,000,000,000", "completed": False},
    {"name": "Nitro Boost", "description": "Own 5 cars with nitro", "completed": False},
    {"name": "Neon Collector", "description": "Own 5 cars with neon", "completed": False},
    {"name": "Legendary Collector", "description": "Collect 5 Legendary cars", "completed": False},
    {"name": "Mythical Hunter", "description": "Collect 3 Mythical cars", "completed": False},
    {"name": "Epic Win", "description": "Win 10 drag races", "completed": False},
    {"name": "Safe Keeper", "description": "Deposit $1,000,000 in the safe", "completed": False},
    {"name": "Banker", "description": "Earn $100,000 in interest", "completed": False},
    {"name": "Drag Racer", "description": "Participate in 20 drag races", "completed": False},
    {"name": "Rare Collector", "description": "Collect 10 Rare cars", "completed": False},
    {"name": "Ultimate Collector", "description": "Own 2 Ultimate cars", "completed": False},
    {"name": "Car Enthusiast", "description": "Own 20 cars", "completed": False},
    {"name": "Speed Addict", "description": "Own a car with speed over 300 mph", "completed": False},
    {"name": "Transcendent Seeker", "description": "Collect a Transcendent car", "completed": False},
    {"name": "Supreme Driver", "description": "Win a race with a Supreme car", "completed": False},
    {"name": "Exotic Owner", "description": "Own 3 Exotic cars", "completed": False},
    {"name": "Luxury Taste", "description": "Own a car worth over $1,000,000", "completed": False},
    {"name": "Box Addict", "description": "Open 100 boxes", "completed": False},
    {"name": "Savings Account", "description": "Deposit $10,000,000 in the safe", "completed": False},
    {"name": "Turbocharger", "description": "Own a car with turbo", "completed": False},
    {"name": "Legendary Win", "description": "Win a race with a Legendary car", "completed": False},
    {"name": "Garage Master", "description": "Own 50 cars", "completed": False},
    {"name": "Celestial Collector", "description": "Collect 2 Celestial cars", "completed": False},
]

quests = [
    {"name": "Collect 5 Cars", "description": "Have 5 cars in your inventory", "completed": False},
    {"name": "Win 3 Races", "description": "Win 3 drag races", "completed": False},
    # Add more quests as needed
]

# Save and Load Functions
def save_game():
    with open('savegame.pkl', 'wb') as f:
        pickle.dump({
            'money': money,
            'safe_money': safe_money,
            'inventory': inventory,
            'safe_inventory': safe_inventory,
            'races_won': races_won,
            'boxes_opened': boxes_opened,
            'total_cars_owned': total_cars_owned,
            'achievements': achievements,
            'quests': quests,
            'trade_offers': trade_offers,
            'jackpot_amount': jackpot_amount,
        }, f)
    print("Game saved!")

def load_game():
    global money, safe_money, inventory, safe_inventory, races_won, boxes_opened, total_cars_owned, achievements, quests, trade_offers, jackpot_amount
    try:
        with open('savegame.pkl', 'rb') as f:
            data = pickle.load(f)
            money = data['money']
            safe_money = data['safe_money']
            inventory = data['inventory']
            safe_inventory = data['safe_inventory']
            races_won = data['races_won']
            boxes_opened = data['boxes_opened']
            total_cars_owned = data['total_cars_owned']
            achievements = data['achievements']
            quests = data['quests']
            trade_offers = data['trade_offers']
            jackpot_amount = data.get('jackpot_amount', 100000)
        print("Game loaded!")
    except FileNotFoundError:
        print("No saved game found.")

# Car rarities and their probabilities
CAR_RARITIES = ['Common', 'Uncommon', 'Rare', 'Epic', 'Legendary', 'Mythical', 'Exotic', 'Special', 'Celestial', 'Ultimate', 'Transcendent', 'Supreme', 'Legendary Classics']
RARITY_COLORS = {
    'Common': (169, 169, 169),
    'Uncommon': (34, 139, 34),
    'Rare': (65, 105, 225),
    'Epic': (138, 43, 226),
    'Legendary': (255, 215, 0),
    'Mythical': (255, 69, 0),
    'Exotic': (255, 20, 147),
    'Special': (173, 216, 230),
    'Celestial': (72, 61, 139),
    'Ultimate': (255, 0, 0),
    'Transcendent': (75, 0, 130),
    'Supreme': (64, 224, 208),
    'Legendary Classics': (255, 223, 0)
}

RARITY_PROBABILITIES = {
    'Common': 50,
    'Uncommon': 30,
    'Rare': 15,
    'Epic': 3,
    'Legendary': 1,
    'Mythical': 0.5,
    'Exotic': 0.3,
    'Special': 0.25,
    'Celestial': 0.1,
    'Ultimate': 0.05,
    'Transcendent': 0.02,
    'Supreme': 0.01,
    'Legendary Classics': 0.005
}

# Car data
CAR_DATA = {
    'Common': [
        ('Toyota Camry', 24000, 130, 'Common'),
        ('Honda Civic', 20000, 125, 'Common'),
        ('Ford Focus', 19000, 120, 'Common'),
        ('Chevrolet Cruze', 18000, 118, 'Common'),
        ('Hyundai Elantra', 19000, 123, 'Common'),
        ('Kia Soul', 17000, 115, 'Common'),
        ('Mazda3', 20000, 128, 'Common'),
        ('Honda Accord', 24000, 130, 'Common'),
        ('Toyota Corolla', 20000, 120, 'Common'),
        ('Ford Fiesta', 15000, 115, 'Common'),
        ('Chevrolet Malibu', 22000, 130, 'Common'),
        ('Hyundai Sonata', 23000, 129, 'Common'),
        ('Kia Optima', 21000, 126, 'Common'),
        ('Nissan Altima', 24000, 130, 'Common'),
        ('Mazda6', 22000, 129, 'Common'),
        ('Volkswagen Passat', 23000, 128, 'Common'),
        ('Subaru Legacy', 22000, 127, 'Common'),
        ('Toyota RAV4', 26000, 120, 'Common'),
        ('Honda CR-V', 25000, 118, 'Common'),
        ('Ford Escape', 25000, 120, 'Common'),
        ('Chevrolet Equinox', 23000, 118, 'Common'),
        ('Hyundai Tucson', 23000, 120, 'Common'),
        ('Kia Sportage', 24000, 118, 'Common'),
        ('Nissan Rogue', 25000, 118, 'Common'),
        ('Mazda CX-5', 25000, 120, 'Common'),
        ('Volkswagen Tiguan', 24000, 120, 'Common'),
        ('Subaru Forester', 24000, 118, 'Common'),
        ('Nissan Sentra', 14000, 115, 'Common'),
        ('Volkswagen Jetta', 12000, 120, 'Common'),
        ('Subaru Impreza', 11000, 115, 'Common')
    ],
    'Uncommon': [
        ('BMW 3 Series', 40000, 155, 'Uncommon'),
        ('Alfa Romeo Giulia', 40000, 160, 'Uncommon'),
        ('Audi A3', 33000, 145, 'Uncommon'),
        ('BMW 2 Series', 35000, 150, 'Uncommon'),
        ('Cadillac ATS', 36000, 149, 'Uncommon'),
        ('Dodge Challenger', 28000, 160, 'Uncommon'),
        ('Fiat 124 Spider', 25000, 140, 'Uncommon'),
        ('Genesis G70', 35000, 155, 'Uncommon'),
        ('Infiniti Q50', 36000, 150, 'Uncommon'),
        ('Jaguar XE', 39000, 155, 'Uncommon'),
        ('Kia Stinger', 33000, 160, 'Uncommon'),
        ('Land Rover Discovery Sport', 37000, 130, 'Uncommon'),
        ('Lexus IS', 38000, 145, 'Uncommon'),
        ('Mini Cooper Clubman', 29000, 140, 'Uncommon'),
        ('Nissan 370Z', 30000, 155, 'Uncommon'),
        ('Peugeot 508', 35000, 150, 'Uncommon'),
        ('Renault Megane RS', 32000, 160, 'Uncommon'),
        ('Saab 9-3', 28000, 140, 'Uncommon'),
        ('Seat Leon Cupra', 34000, 150, 'Uncommon'),
        ('Skoda Octavia RS', 30000, 150, 'Uncommon'),
        ('Tesla Model 3', 48000, 162, 'Uncommon'),
        ('Vauxhall Insignia VXR', 38000, 150, 'Uncommon'),
        ('Volvo S60', 36000, 150, 'Uncommon'),
        ('Acura TLX', 37000, 145, 'Uncommon'),
        ('Buick Regal GS', 39000, 150, 'Uncommon'),
        ('Chevrolet SS', 47000, 160, 'Uncommon'),
        ('Chrysler 300 SRT', 51000, 155, 'Uncommon'),
        ('Ford Mustang GT', 36000, 155, 'Uncommon'),
        ('Honda S2000', 34000, 145, 'Uncommon')
    ],
    'Rare': [
        ('Porsche Macan', 50000, 155, 'Rare'),
        ('Alfa Romeo Stelvio', 45000, 160, 'Rare'),
        ('Jaguar F-Pace', 42000, 155, 'Rare'),
        ('Cadillac XT5', 41000, 150, 'Rare'),
        ('BMW X3', 47000, 155, 'Rare'),
        ('Audi Q5', 43000, 155, 'Rare'),
        ('Mercedes-Benz GLC', 40000, 155, 'Rare'),
        ('Lexus RX', 44000, 145, 'Rare'),
        ('Volvo XC60', 39000, 150, 'Rare'),
        ('Infiniti QX50', 37000, 150, 'Rare')
    ],
    'Epic': [
        ('Tesla Model S', 80000, 200, 'Epic'),
        ('BMW i8', 147000, 155, 'Epic'),
        ('Porsche 911', 99000, 190, 'Epic'),
        ('Audi RS 5', 74000, 174, 'Epic'),
        ('Mercedes-Benz S-Class', 94000, 155, 'Epic'),
        ('Range Rover Sport', 68000, 140, 'Epic'),
        ('Maserati Ghibli', 75000, 178, 'Epic'),
        ('Lexus LC', 92000, 168, 'Epic'),
        ('Aston Martin DB11', 201000, 200, 'Epic'),
        ('Bentley Continental GT', 202000, 207, 'Epic')
    ],
    'Legendary': [
        ('Ferrari 488', 280000, 211, 'Legendary'),
        ('Lamborghini Huracan', 240000, 202, 'Legendary'),
        ('McLaren 720S', 300000, 212, 'Legendary'),
        ('Aston Martin Vantage', 140000, 195, 'Legendary'),
        ('Porsche Taycan Turbo S', 185000, 161, 'Legendary'),
        ('Ferrari F8 Tributo', 276000, 211, 'Legendary'),
        ('Lamborghini Aventador', 417000, 217, 'Legendary'),
        ('Rolls-Royce Wraith', 330000, 155, 'Legendary'),
        ('Bentley Flying Spur', 214000, 207, 'Legendary'),
        ('McLaren GT', 210000, 203, 'Legendary')
    ],
    'Mythical': [
        ('Hennessey Venom F5', 1800000, 250, 'Mythical'),
        ('Lotus Evija', 2000000, 217, 'Mythical'),
        ('Rimac C_Two', 2100000, 258, 'Mythical'),
        ('Aston Martin Valkyrie', 3000000, 220, 'Mythical'),
        ('Mercedes-AMG Project One', 2700000, 217, 'Mythical'),
        ('Pininfarina Battista', 2200000, 217, 'Mythical'),
        ('Bugatti Chiron Super Sport 300+', 4000000, 304, 'Mythical'),
        ('Koenigsegg Jesko Absolut', 3000000, 330, 'Mythical'),
        ('SSC Tuatara', 2000000, 283, 'Mythical'),
        ('Gordon Murray T.50', 2800000, 217, 'Mythical')
    ],
    'Exotic': [
        ('Chevrolet Corvette ZR1', 120000, 212, 'Exotic'),
        ('Dodge Viper ACR', 150000, 177, 'Exotic'),
        ('Nissan GT-R Nismo', 210000, 205, 'Exotic'),
        ('Jaguar F-Type SVR', 130000, 200, 'Exotic'),
        ('Acura NSX', 157000, 191, 'Exotic'),
        ('McLaren 720S Spider', 315000, 212, 'Exotic'),
        ('Lamborghini Huracan Performante', 274000, 202, 'Exotic'),
        ('Ferrari 488 Pista', 350000, 211, 'Exotic'),
        ('Porsche 911 GT2 RS', 293000, 211, 'Exotic'),
        ('Aston Martin Vanquish Zagato', 850000, 201, 'Exotic')
    ],
    'Special': [
        ('Oscar Mayer Wienermobile', 100000, 60, 'Special'),
        ('Batman Tumbler', 1000000, 160, 'Special'),
        ('DeLorean DMC-12 (Back to the Future)', 85000, 88, 'Special'),
        ('Ecto-1 (Ghostbusters)', 200000, 80, 'Special'),
        ('The Flintstones Car', 3000, 10, 'Special'),
        ('Mutt Cutts Van (Dumb and Dumber)', 50000, 75, 'Special'),
        ('Peel P50', 120000, 38, 'Special'),
        ('Reliant Regal (Mr. Bean)', 15000, 55, 'Special'),
        ('Jet Car (The Jetsons)', 300000, 300, 'Special'),
        ('AeroMobil 3.0 Flying Car', 1000000, 160, 'Special'),
        ('John Deere X9 Combine', 1079000, 25, 'Special'),
        ('M1 Abrams Tank', 6000000, 42, 'Special')
    ],
    'Celestial': [
        ('Mercedes-Maybach S 650 Cabriolet', 300000, 155, 'Celestial'),
        ('Rolls-Royce Boat Tail', 28000000, 155, 'Celestial'),
        ('Bentley Bacalar', 1900000, 200, 'Celestial'),
        ('Rolls-Royce Sweptail', 13000000, 150, 'Celestial'),
        ('Mercedes-Maybach G 650 Landaulet', 850000, 112, 'Celestial'),
        ('Aston Martin Lagonda Taraf', 1000000, 195, 'Celestial'),
        ('Rolls-Royce Phantom Oribe', 450000, 155, 'Celestial'),
        ('Bentley Mulliner Bacalar', 2000000, 200, 'Celestial'),
        ('Rolls-Royce Ghost Extended', 400000, 155, 'Celestial'),
        ('Maybach Zeppelin', 1800000, 150, 'Celestial')
    ],
    'Ultimate': [
        ('Bugatti Bolide', 5000000, 311, 'Ultimate'),
        ('Ferrari FXX K Evo', 4000000, 217, 'Ultimate'),
        ('Lamborghini Sesto Elemento', 2800000, 211, 'Ultimate'),
        ('McLaren Elva', 1700000, 203, 'Ultimate'),
        ('Aston Martin AM-RB 003', 1000000, 217, 'Ultimate'),
        ('Koenigsegg One:1', 6000000, 273, 'Ultimate'),
        ('Pagani Imola', 5000000, 233, 'Ultimate'),
        ('Ferrari Monza SP2', 1800000, 186, 'Ultimate'),
        ('Lamborghini Centenario LP 770-4', 2500000, 217, 'Ultimate'),
        ('McLaren Sabre', 3700000, 218, 'Ultimate')
    ],
    'Transcendent': [
        ('Bugatti La Voiture Noire', 18680000, 261, 'Transcendent'),
        ('Rolls-Royce Sweptail', 13000000, 150, 'Transcendent'),
        ('Mercedes-Benz Maybach Exelero', 8000000, 218, 'Transcendent'),
        ('Koenigsegg CCXR Trevita', 4800000, 254, 'Transcendent'),
        ('Lamborghini Veneno Roadster', 4500000, 221, 'Transcendent'),
        ('McLaren P1 LM', 3600000, 217, 'Transcendent'),
        ('Lykan Hypersport', 3400000, 245, 'Transcendent'),
        ('Aston Martin Valkyrie', 3000000, 220, 'Transcendent'),
        ('Pagani Huayra BC', 2800000, 238, 'Transcendent'),
        ('Ferrari Pininfarina Sergio', 3000000, 199, 'Transcendent')
    ],
    'Supreme': [
        ('Bugatti Centodieci', 9000000, 236, 'Supreme'),
        ('Aston Martin Victor', 3000000, 220, 'Supreme'),
        ('McLaren Speedtail', 2250000, 250, 'Supreme'),
        ('Lamborghini Sian FKP 37', 3600000, 220, 'Supreme'),
        ('Pagani Zonda HP Barchetta', 17500000, 221, 'Supreme'),
        ('Ferrari LaFerrari Aperta', 2200000, 217, 'Supreme'),
        ('Koenigsegg Jesko', 3000000, 330, 'Supreme'),
        ('Rolls-Royce Boat Tail', 28000000, 155, 'Supreme'),
        ('Bentley Mulliner Bacalar', 1900000, 200, 'Supreme'),
        ('Porsche 918 Spyder', 1150000, 211, 'Supreme')
    ],
    'Legendary Classics': [
        ('1963 Ferrari 250 GTO', 70000000, 174, 'Legendary Classics'),
        ('1957 Ferrari 335 S', 35000000, 190, 'Legendary Classics'),
        ('1954 Mercedes-Benz W196', 30000000, 186, 'Legendary Classics'),
        ('1956 Ferrari 290 MM', 28000000, 177, 'Legendary Classics'),
        ('1967 Ferrari 275 GTB/4*S NART Spider', 27500000, 166, 'Legendary Classics'),
        ('1964 Ferrari 275 GTB/C Speciale', 26000000, 167, 'Legendary Classics'),
        ('1955 Jaguar D-Type', 23000000, 172, 'Legendary Classics'),
        ('1961 Ferrari 250 GT SWB California Spider', 18500000, 150, 'Legendary Classics'),
        ('1956 Aston Martin DBR1', 22500000, 160, 'Legendary Classics'),
        ('1962 Aston Martin DB4GT Zagato', 14000000, 153, 'Legendary Classics'),
        ('Mercedes-Benz 300 SLR Gullwing Uhlenhaut', 142500000, 180, 'Legendary Classics')
    ]
}

# Utility functions
def format_money(value):
    if value < 1e3:
        return str(value)
    elif value < 1e6:
        return f"{value/1e3:.1f}K"
    elif value < 1e9:
        return f"{value/1e6:.1f}M"
    elif value < 1e12:
        return f"{value/1e9:.1f}B"
    elif value < 1e15:
        return f"{value/1e12:.1f}T"
    else:
        return f"{value/1e15:.1f}Q"

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
NEON_GREEN = (57, 255, 20)
DARK_RED = (139, 0, 0)
YELLOW = (255, 255, 0)
ORANGE = (255, 165, 0)

# Button class
class Button:
    def __init__(self, color, x, y, width, height, text=''):
        self.color = color
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.text = text

    def draw(self, win, outline=None):
        if outline:
            pygame.draw.rect(win, outline, (self.x - 2, self.y - 2, self.width + 4, self.height + 4), 0)
        pygame.draw.rect(win, self.color, (self.x, self.y, self.width, self.height), 0)
        if self.text != '':
            font = pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.04))
            text = font.render(self.text, True, BLACK)
            win.blit(text, (self.x + (self.width / 2 - text.get_width() / 2), self.y + (self.height / 2 - text.get_height() / 2)))

    def is_over(self, pos):
        return self.x < pos[0] < self.x + self.width and self.y < pos[1] < self.y + self.height

# Create buttons
open_box_button = Button(WHITE, 20, int(SCREEN_HEIGHT * 0.3), int(SCREEN_WIDTH * 0.25), int(SCREEN_HEIGHT * 0.07), 'Open Box')
inventory_button = Button(WHITE, 20, int(SCREEN_HEIGHT * 0.35), int(SCREEN_WIDTH * 0.25), int(SCREEN_HEIGHT * 0.07), 'Inventory')
probability_button = Button(WHITE, 20, int(SCREEN_HEIGHT * 0.4), int(SCREEN_WIDTH * 0.25), int(SCREEN_HEIGHT * 0.07), 'Probability')
race_button = Button(WHITE, 20, int(SCREEN_HEIGHT * 0.45), int(SCREEN_WIDTH * 0.25), int(SCREEN_HEIGHT * 0.07), 'Drag Race')
safe_button = Button(WHITE, 20, int(SCREEN_HEIGHT * 0.5), int(SCREEN_WIDTH * 0.25), int(SCREEN_HEIGHT * 0.07), 'Safe')
car_index_button = Button(WHITE, 20, int(SCREEN_HEIGHT * 0.55), int(SCREEN_WIDTH * 0.25), int(SCREEN_HEIGHT * 0.07), 'Car Index')
achievements_button = Button(WHITE, 20, int(SCREEN_HEIGHT * 0.6), int(SCREEN_WIDTH * 0.25), int(SCREEN_HEIGHT * 0.07), 'Achievements')
back_button = Button(WHITE, 20, SCREEN_HEIGHT - 100, int(SCREEN_WIDTH * 0.25), int(SCREEN_HEIGHT * 0.07), 'Back to Menu')
sort_button = Button(WHITE, SCREEN_WIDTH - 220, 80, 200, 40, 'Sort by Speed')
next_page_button = Button(WHITE, SCREEN_WIDTH - 220, SCREEN_HEIGHT - 60, 200, 40, 'Next Page')
prev_page_button = Button(WHITE, 20, SCREEN_HEIGHT - 60, 200, 40, 'Previous Page')
deposit_money_button = Button(WHITE, SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT - 200, 200, 40, 'Deposit Money')
withdraw_money_button = Button(WHITE, SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT - 150, 200, 40, 'Withdraw Money')
deposit_car_button = Button(WHITE, SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT - 250, 200, 40, 'Deposit Car')
withdraw_car_button = Button(WHITE, SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT - 100, 200, 40, 'Withdraw Car')
sell_duplicates_button = Button(WHITE, SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT - 50, 200, 40, 'Sell Duplicates')
sort_by_speed_button = Button(WHITE, SCREEN_WIDTH - 420, 80, 200, 40, 'Sort by Speed')
sort_by_rarity_button = Button(WHITE, SCREEN_WIDTH - 620, 80, 200, 40, 'Sort by Rarity')
sort_by_price_button = Button(WHITE, SCREEN_WIDTH - 220, 80, 200, 40, 'Sort by Price')
save_button = Button(WHITE, 20, int(SCREEN_HEIGHT * 0.65), int(SCREEN_WIDTH * 0.25), int(SCREEN_HEIGHT * 0.07), 'Save Game')
load_button = Button(WHITE, 20, int(SCREEN_HEIGHT * 0.7), int(SCREEN_WIDTH * 0.25), int(SCREEN_HEIGHT * 0.07), 'Load Game')
list_car_button = Button(WHITE, 20, int(SCREEN_HEIGHT * 0.75), int(SCREEN_WIDTH * 0.25), int(SCREEN_HEIGHT * 0.07), 'List Car for Trade')
global_market_button = Button(WHITE, 20, int(SCREEN_HEIGHT * 0.8), int(SCREEN_WIDTH * 0.25), int(SCREEN_HEIGHT * 0.07), 'Global Market')
coinflip_button = Button(WHITE, 20, int(SCREEN_HEIGHT * 0.85), int(SCREEN_WIDTH * 0.25), int(SCREEN_HEIGHT * 0.07), 'Coinflip')

# Helper functions
def draw_text(text, font, color, surface, x, y):
    textobj = font.render(text, True, color)
    textrect = textobj.get_rect()
    textrect.topleft = (x, y)
    surface.blit(textobj, textrect)

def apply_modifiers(car):
    name, price, speed, rarity = car
    neon = random.random() < 0.01
    nitro = random.random() < 0.01
    if neon and nitro:
        name = f"N{name}"
        price *= 1.3
        speed += 15
    elif neon:
        name = f"N{name}"
        price *= 1.1
        speed += 5
    elif nitro:
        name = f"N{name}"
        price *= 1.1
        speed += 10
    return name, price, speed, rarity, neon, nitro

def open_box():
    global money, inventory, boxes_opened, total_cars_owned
    if money >= BOX_PRICE:
        money -= BOX_PRICE
        boxes_opened += 1
        rarity = random.choices(CAR_RARITIES, weights=list(RARITY_PROBABILITIES.values()), k=1)[0]
        car = random.choice(CAR_DATA[rarity])
        car = apply_modifiers(car)
        inventory.append(car)
        total_cars_owned += 1
        check_achievements()
        return f"You got a {rarity} car: {car[0]}!"
    else:
        return "Not enough money to open a box."

def sell_car(index):
    global money, inventory
    if 0 <= index < len(inventory):
        car = inventory.pop(index)
        money += car[1]
        check_achievements()
        return f"You sold {car[0]} for ${format_money(car[1])}."
    else:
        return "Invalid selection."

def sell_duplicates():
    global money, inventory
    car_counter = Counter((car[0], car[4], car[5]) for car in inventory)
    for car_key, count in car_counter.items():
        if count > 1:
            for _ in range(count - 1):
                for car in inventory:
                    if (car[0], car[4], car[5]) == car_key:
                        inventory.remove(car)
                        money += car[1]
                        break
    check_achievements()

def check_achievements():
    global races_won, boxes_opened, total_cars_owned, safe_money
    # Check achievements and quests
    if not achievements[0]["completed"] and boxes_opened >= 1:
        achievements[0]["completed"] = True
    if not achievements[1]["completed"] and money >= 1000000:
        achievements[1]["completed"] = True
    if not achievements[2]["completed"] and total_cars_owned >= 10:
        achievements[2]["completed"] = True
    if not achievements[3]["completed"] and races_won >= 5:
        achievements[3]["completed"] = True
    if not achievements[4]["completed"] and money >= 10000000:
        achievements[4]["completed"] = True
    if not achievements[5]["completed"] and any(car[2] > 250 for car in inventory):
        achievements[5]["completed"] = True
    if not achievements[6]["completed"] and boxes_opened >= 50:
        achievements[6]["completed"] = True
    if not achievements[7]["completed"] and money >= 1000000000:
        achievements[7]["completed"] = True
    if not achievements[8]["completed"] and sum(1 for car in inventory if car[5]) >= 5:
        achievements[8]["completed"] = True
    if not achievements[9]["completed"] and sum(1 for car in inventory if car[4]) >= 5:
        achievements[9]["completed"] = True
    if not achievements[10]["completed"] and sum(1 for car in inventory if car[3] == 'Legendary') >= 5:
        achievements[10]["completed"] = True
    if not achievements[11]["completed"] and sum(1 for car in inventory if car[3] == 'Mythical') >= 3:
        achievements[11]["completed"] = True
    if not achievements[12]["completed"] and races_won >= 10:
        achievements[12]["completed"] = True
    if not achievements[13]["completed"] and safe_money >= 1000000:
        achievements[13]["completed"] = True
    if not achievements[14]["completed"] and safe_money * 0.05 >= 100000:
        achievements[14]["completed"] = True
    if not achievements[15]["completed"] and sum(1 for car in inventory if car) >= 20:
        achievements[15]["completed"] = True
    if not achievements[16]["completed"] and sum(1 for car in inventory if car[3] == 'Rare') >= 10:
        achievements[16]["completed"] = True
    if not achievements[17]["completed"] and sum(1 for car in inventory if car[3] == 'Ultimate') >= 2:
        achievements[17]["completed"] = True
    if not achievements[18]["completed"] and total_cars_owned >= 20:
        achievements[18]["completed"] = True
    if not achievements[19]["completed"] and any(car[2] > 300 for car in inventory):
        achievements[19]["completed"] = True
    if not achievements[20]["completed"] and any(car[3] == 'Transcendent' for car in inventory):
        achievements[20]["completed"] = True
    if not achievements[21]["completed"] and any(car[3] == 'Supreme' and races_won > 0 for car in inventory):
        achievements[21]["completed"] = True
    if not achievements[22]["completed"] and sum(1 for car in inventory if car[3] == 'Exotic') >= 3:
        achievements[22]["completed"] = True
    if not achievements[23]["completed"] and any(car[1] > 1000000 for car in inventory):
        achievements[23]["completed"] = True
    if not achievements[24]["completed"] and boxes_opened >= 100:
        achievements[24]["completed"] = True
    if not achievements[25]["completed"] and safe_money >= 10000000:
        achievements[25]["completed"] = True
    if not achievements[26]["completed"] and any(car[3] == 'Ultimate' for car in inventory):
        achievements[26]["completed"] = True
    if not achievements[27]["completed"] and any(car[3] == 'Legendary' and races_won > 0 for car in inventory):
        achievements[27]["completed"] = True
    if not achievements[28]["completed"] and total_cars_owned >= 50:
        achievements[28]["completed"] = True
    if not achievements[29]["completed"] and sum(1 for car in inventory if car[3] == 'Celestial') >= 2:
        achievements[29]["completed"] = True

    # Check quests
    if not quests[0]["completed"] and len(inventory) >= 5:
        quests[0]["completed"] = True
    if not quests[1]["completed"] and races_won >= 3:
        quests[1]["completed"] = True

def calculate_interest_rate(safe_balance):
    if safe_balance < 100000:
        return 0.05
    elif safe_balance < 1000000:
        return 0.03
    elif safe_balance < 10000000:
        return 0.02
    elif safe_balance < 100000000:
        return 0.01
    else:
        return 0.005

def generate_trade_offer():
    rarity = random.choices(CAR_RARITIES, weights=list(RARITY_PROBABILITIES.values()), k=1)[0]
    car = random.choice(CAR_DATA[rarity])
    car = apply_modifiers(car)

    offer_type = random.choice(['sell', 'trade', 'trade_plus_money', 'buy'])
    if offer_type == 'sell':
        price_multiplier = 1 + random.uniform(0.5, 1.5)
        offer = {'type': 'sell', 'car': car, 'price': car[1] * price_multiplier}
    elif offer_type == 'trade':
        trade_rarity = random.choices(CAR_RARITIES, weights=list(RARITY_PROBABILITIES.values()), k=1)[0]
        trade_car = random.choice(CAR_DATA[trade_rarity])
        trade_car = apply_modifiers(trade_car)
        offer = {'type': 'trade', 'car': car, 'trade_for': trade_car}
    elif offer_type == 'trade_plus_money':
        trade_rarity = random.choices(CAR_RARITIES, weights=list(RARITY_PROBABILITIES.values()), k=1)[0]
        trade_car = random.choice(CAR_DATA[trade_rarity])
        trade_car = apply_modifiers(trade_car)
        price_difference = car[1] - trade_car[1]
        if price_difference > 0:
            offer = {'type': 'trade_plus_money', 'car': car, 'trade_for': trade_car, 'money': price_difference}
        else:
            offer = {'type': 'trade_plus_money', 'car': trade_car, 'trade_for': car, 'money': -price_difference}
    else:  # buy
        price_multiplier = 1 + random.uniform(0.5, 1.5)
        offer = {'type': 'buy', 'car': car, 'price': car[1] * price_multiplier}

    trade_offers.append(offer)

def evaluate_trade_quality(offer):
    if offer['type'] == 'sell' or offer['type'] == 'buy':
        quality = offer['price'] / offer['car'][1]
        if quality < 0.8:
            return NEON_GREEN  # Very good
        elif quality < 1:
            return GREEN  # Good
        elif quality < 1.2:
            return YELLOW  # Okay
        elif quality < 1.5:
            return ORANGE  # Bad
        else:
            return RED  # Very bad
    elif offer['type'] == 'trade':
        quality = offer['car'][1] / offer['trade_for'][1]
        if quality < 0.8:
            return NEON_GREEN  # Very good
        elif quality < 1:
            return GREEN  # Good
        elif quality < 1.2:
            return YELLOW  # Okay
        elif quality < 1.5:
            return ORANGE  # Bad
        else:
            return RED  # Very bad
    elif offer['type'] == 'trade_plus_money':
        quality = (offer['car'][1] + offer['money']) / offer['trade_for'][1]
        if quality < 0.8:
            return NEON_GREEN  # Very good
        elif quality < 1:
            return GREEN  # Good
        elif quality < 1.2:
            return YELLOW  # Okay
        elif quality < 1.5:
            return ORANGE  # Bad
        else:
            return RED  # Very bad

def bot_buy_car():
    global trade_offers, inventory, money
    if trade_offers:
        offer = random.choice(trade_offers)
        if offer['type'] == 'sell':
            # Ensure the car being bought by the bot is not in the player's inventory
            if offer['car'] in inventory:
                inventory.remove(offer['car'])
            money += offer['price']
            trade_offers.remove(offer)
            print(f"Bot bought {offer['car'][0]} for ${format_money(offer['price'])}")

def main_menu():
    global money, current_screen, next_trade_tick, next_bot_trade_tick
    screen.fill(WHITE)
    draw_text('Car Collection Game', pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.1)), BLACK, screen, 20, 20)
    draw_text(f"Money: ${format_money(money)}", pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.05)), BLACK, screen, 20, 80)
    draw_text('Click to earn money', pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.05)), BLACK, screen, 20, 120)
    draw_text('Boxes cost $20k', pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.05)), BLACK, screen, 20, 160)

    # Draw buttons
    open_box_button.draw(screen, BLACK)
    inventory_button.draw(screen, BLACK)
    probability_button.draw(screen, BLACK)
    race_button.draw(screen, BLACK)
    safe_button.draw(screen, BLACK)
    car_index_button.draw(screen, BLACK)
    achievements_button.draw(screen, BLACK)
    save_button.draw(screen, BLACK)  # Added save button
    load_button.draw(screen, BLACK)  # Added load button
    list_car_button.draw(screen, BLACK)  # Added list car button
    global_market_button.draw(screen, BLACK)  # Added global market button
    coinflip_button.draw(screen, BLACK)  # Added coinflip button

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            if event.button == 1:  # Left click
                if open_box_button.is_over(pos):
                    print(open_box())
                elif inventory_button.is_over(pos):
                    current_screen = 'inventory'
                elif probability_button.is_over(pos):
                    current_screen = 'probability'
                elif race_button.is_over(pos):
                    current_screen = 'drag_race'
                elif safe_button.is_over(pos):
                    current_screen = 'safe'
                elif car_index_button.is_over(pos):
                    current_screen = 'car_index'
                elif achievements_button.is_over(pos):
                    current_screen = 'achievements'
                elif save_button.is_over(pos):  # Handle save button click
                    save_game()
                elif load_button.is_over(pos):  # Handle load button click
                    load_game()
                elif list_car_button.is_over(pos):
                    current_screen = 'list_car'
                elif global_market_button.is_over(pos):
                    current_screen = 'global_market'
                elif coinflip_button.is_over(pos):
                    current_screen = 'coinflip'
                else:
                    money += MONEY_PER_CLICK
                    check_achievements()

    # Generate new trade offers periodically
    if time.time() >= next_trade_tick:
        generate_trade_offer()
        next_trade_tick = time.time() + TRADE_TICK_INTERVAL

    # Bot buys car from the market
    if time.time() >= next_bot_trade_tick:
        bot_buy_car()
        next_bot_trade_tick = time.time() + BOT_TRADE_INTERVAL

def inventory_screen():
    global current_screen, inventory_page, sort_by_speed, sort_by_rarity, sort_by_price
    screen.fill(WHITE)
    draw_text('Inventory', pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.1)), BLACK, screen, 20, 20)

    # Calculate total value
    total_value = sum(car[1] for car in inventory)
    formatted_total_value = format_money(total_value)
    draw_text(f'Total Value: {formatted_total_value}', pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.05)), BLACK, screen, SCREEN_WIDTH - 500, 20)

    # Draw buttons
    back_button.draw(screen, BLACK)
    next_page_button.draw(screen, BLACK)
    prev_page_button.draw(screen, BLACK)
    sell_duplicates_button.draw(screen, BLACK)
    sort_by_speed_button.draw(screen, BLACK)
    sort_by_rarity_button.draw(screen, BLACK)
    sort_by_price_button.draw(screen, BLACK)

    # Sort and display inventory based on the chosen criteria
    if sort_by_speed:
        sorted_inventory = sorted(Counter(inventory).items(), key=lambda x: x[0][2], reverse=True)
    elif sort_by_rarity:
        rarity_order = {rarity: i for i, rarity in enumerate(CAR_RARITIES)}
        sorted_inventory = sorted(Counter(inventory).items(), key=lambda x: rarity_order[x[0][3]])
    elif sort_by_price:
        sorted_inventory = sorted(Counter(inventory).items(), key=lambda x: x[0][1], reverse=True)
    else:
        sorted_inventory = sorted(Counter(inventory).items(), key=lambda x: x[0][1], reverse=True)

    page_inventory = sorted_inventory[inventory_page * INVENTORY_SIZE_PER_PAGE:(inventory_page + 1) * INVENTORY_SIZE_PER_PAGE]

    start_y = 120
    for index, ((car_name, car_price, car_speed, car_rarity, neon, nitro), count) in enumerate(page_inventory):
        rarity_color = RARITY_COLORS[car_rarity]
        prefix_color = None
        prefix = ""

        if neon and nitro:
            prefix_color = (NEON_GREEN, DARK_RED)
            prefix = "N"
        elif neon:
            prefix_color = (NEON_GREEN,)
            prefix = "N"
        elif nitro:
            prefix_color = (DARK_RED,)
            prefix = "N"

        draw_text(f"{car_name} x{count} - ${format_money(car_price)}, Speed: {car_speed} mph", pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.04)), rarity_color, screen, 60, start_y)

        # Draw prefixes
        if prefix:
            for i, color in enumerate(prefix_color):
                draw_text(prefix, pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.04)), color, screen, 40 + i * 15, start_y)

        start_y += 28

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            if event.button == 1:  # Left click
                if back_button.is_over(pos):
                    current_screen = 'main_menu'
                elif next_page_button.is_over(pos) and (inventory_page + 1) * INVENTORY_SIZE_PER_PAGE < len(sorted_inventory):
                    inventory_page += 1
                elif prev_page_button.is_over(pos) and inventory_page > 0:
                    inventory_page -= 1
                elif sell_duplicates_button.is_over(pos):
                    sell_duplicates()
                elif sort_by_speed_button.is_over(pos):
                    sort_by_speed = True
                    sort_by_rarity = False
                    sort_by_price = False
                elif sort_by_rarity_button.is_over(pos):
                    sort_by_rarity = True
                    sort_by_speed = False
                    sort_by_price = False
                elif sort_by_price_button.is_over(pos):
                    sort_by_price = True
                    sort_by_speed = False
                    sort_by_rarity = False
                else:
                    for index, ((car_name, car_price, car_speed, car_rarity, neon, nitro), count) in enumerate(page_inventory):
                        car_pos_y = 120 + index * 28  # Adjusted to match the text spacing
                        if 40 < pos[0] < SCREEN_WIDTH // 2 and car_pos_y < pos[1] < car_pos_y + 28:
                            car_to_sell = (car_name, car_price, car_speed, car_rarity, neon, nitro)
                            car_index = inventory.index(car_to_sell)
                            print(sell_car(car_index))
                            break

def probability_screen():
    global current_screen
    screen.fill(WHITE)
    draw_text('Rarity Probabilities', pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.1)), BLACK, screen, 20, 20)
    start_y = 80

    for rarity in CAR_RARITIES:
        color = RARITY_COLORS[rarity]
        probability = RARITY_PROBABILITIES[rarity]
        draw_text(f"{rarity}: {probability}%", pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.04)), color, screen, 20, start_y)
        start_y += 19

    # Add Nitro and Neon probabilities with colors
    draw_text("Nitro Chance: 1%", pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.04)), DARK_RED, screen, 20, start_y)
    start_y += 23
    draw_text("Neon Chance: 1%", pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.04)), NEON_GREEN, screen, 20, start_y)
    start_y += 23

    back_button.draw(screen, BLACK)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            if event.button == 1:  # Left click
                if back_button.is_over(pos):
                    current_screen = 'main_menu'

def drag_race_screen():
    global current_screen, selected_car, money, race_in_progress, player_car_pos, opponent_car_pos, opponent_car, race_start_time, race_page, races_won, sort_by_speed, sort_by_price
    screen.fill(WHITE)
    draw_text('Drag Race', pygame.font.SysFont(None, 50), BLACK, screen, 20, 20)

    if race_in_progress:
        # Draw the road
        road_color = (50, 50, 50)
        lane_color = (255, 255, 255)
        road_height = 150
        pygame.draw.rect(screen, road_color, (0, SCREEN_HEIGHT // 2 - road_height // 2, SCREEN_WIDTH, road_height))

        # Draw lane dividers
        for i in range(0, SCREEN_WIDTH, 40):
            pygame.draw.line(screen, lane_color, (i, SCREEN_HEIGHT // 2), (i + 20, SCREEN_HEIGHT // 2), 2)

        elapsed_time = time.time() - race_start_time
        if (elapsed_time > 7):
            race_in_progress = False
            result_text = ""
            if selected_car and opponent_car:
                if player_car_pos >= opponent_car_pos:
                    result_text = f"You won! Your {selected_car[0]} beat the {opponent_car[0]}!"
                    money_reward = selected_car[1] * 0.1
                    races_won += 1
                else:
                    result_text = f"You lost! Your {selected_car[0]} was beaten by the {opponent_car[0]}."
                    money_reward = -selected_car[1] * 0.1

                money += money_reward
                draw_text(result_text, pygame.font.SysFont(None, 36), BLACK, screen, 20, 120)
                draw_text(f"Money: ${format_money(money)}", pygame.font.SysFont(None, 36), BLACK, screen, 20, 160)
                check_achievements()
            selected_car = None
            opponent_car = None
        else:
            if selected_car and opponent_car:
                player_car_speed = selected_car[2] / 200
                opponent_car_speed = opponent_car[2] / 200

                player_car_pos += player_car_speed
                opponent_car_pos += opponent_car_speed

                pygame.draw.rect(screen, RARITY_COLORS[selected_car[3]], (player_car_pos, SCREEN_HEIGHT // 2 - 50, 50, 20))
                pygame.draw.rect(screen, RARITY_COLORS[opponent_car[3]], (opponent_car_pos, SCREEN_HEIGHT // 2 + 30, 50, 20))
    else:
        if selected_car:
            opponent_car = random.choice(random.choice(list(CAR_DATA.values())))
            opponent_car = apply_modifiers(opponent_car)
            player_car_pos = 0
            opponent_car_pos = 0
            race_start_time = time.time()
            race_in_progress = True
        else:
            draw_text('Select a car from your inventory', pygame.font.SysFont(None, 36), BLACK, screen, 20, 80)

            # Sort inventory based on criteria
            if sort_by_speed:
                sorted_inventory = sorted(inventory, key=lambda x: x[2], reverse=True)
            elif sort_by_price:
                sorted_inventory = sorted(inventory, key=lambda x: x[1], reverse=True)
            else:
                sorted_inventory = inventory

            start_y = 160
            cars_per_page = 10
            start_index = race_page * cars_per_page
            end_index = start_index + cars_per_page
            displayed_cars = sorted_inventory[start_index:end_index]

            car_rects = []
            for index, (car_name, car_price, car_speed, car_rarity, neon, nitro) in enumerate(displayed_cars):
                rarity_color = RARITY_COLORS[car_rarity]
                prefix_color = None
                prefix = ""

                if neon and nitro:
                    prefix_color = (NEON_GREEN, DARK_RED)
                    prefix = "N"
                elif neon:
                    prefix_color = (NEON_GREEN,)
                    prefix = "N"
                elif nitro:
                    prefix_color = (DARK_RED,)
                    prefix = "N"

                car_rect = pygame.Rect(40, start_y, SCREEN_WIDTH // 2, 21)  # Hitbox for the car name
                car_rects.append((car_rect, (car_name, car_price, car_speed, car_rarity, neon, nitro)))
                draw_text(f"{index + 1}. {car_name} - ${format_money(car_price)}, Speed: {car_speed} mph", pygame.font.SysFont(None, 21), rarity_color, screen, 60, start_y)

                # Draw prefixes
                if prefix:
                    for i, color in enumerate(prefix_color):
                        draw_text(prefix, pygame.font.SysFont(None, 21), color, screen, 40 + i * 15, start_y)

                start_y += 21  # Visual spacing

            sort_by_speed_button.draw(screen, BLACK)
            sort_by_price_button.draw(screen, BLACK)
            next_page_button.draw(screen, BLACK)
            prev_page_button.draw(screen, BLACK)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    pos = pygame.mouse.get_pos()
                    if event.button == 1:
                        if back_button.is_over(pos):
                            current_screen = 'main_menu'
                            selected_car = None
                            opponent_car = None
                        elif sort_by_speed_button.is_over(pos):
                            sort_by_speed = True
                            sort_by_price = False
                        elif sort_by_price_button.is_over(pos):
                            sort_by_price = True
                            sort_by_speed = False
                        elif next_page_button.is_over(pos) and end_index < len(inventory):
                            race_page += 1
                        elif prev_page_button.is_over(pos) and race_page > 0:
                            race_page -= 1
                        else:
                            for car_rect, car in car_rects:
                                if car_rect.collidepoint(pos):
                                    selected_car = car
                                    break

    if opponent_car:
        draw_text(f"Opponent Car: {opponent_car[0]}, Speed: {opponent_car[2]} mph", pygame.font.SysFont(None, 24), BLACK, screen, 20, 100)
        draw_text(f"Prize for Winning: ${format_money(selected_car[1] * 0.1)}", pygame.font.SysFont(None, 24), GREEN, screen, 20, 120)
        draw_text(f"Penalty for Losing: ${format_money(selected_car[1] * 0.1)}", pygame.font.SysFont(None, 24), RED, screen, 20, 140)

    back_button.draw(screen, BLACK)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            if event.button == 1:
                if back_button.is_over(pos):
                    current_screen = 'main_menu'
                    selected_car = None
                    opponent_car = None

def safe_screen():
    global current_screen, safe_money, safe_inventory, inventory, money, safe_inventory_page, inventory_page, selected_car, sort_by_speed, sort_by_price
    screen.fill(WHITE)
    draw_text('Safe', pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.1)), BLACK, screen, 20, 20)
    draw_text(f"Money in Safe: ${format_money(safe_money)}", pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.05)), BLACK, screen, 20, 60)
    draw_text(f"Total Money: ${format_money(money)}", pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.05)), BLACK, screen, 20, 100)
    draw_text(f"Interest Rate: {calculate_interest_rate(safe_money) * 100:.2f}% per minute", pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.04)), BLACK, screen, 20, 140)

    total_safe_value = sum(car[1] for car in safe_inventory)
    draw_text(f"Safe Car Value: ${format_money(total_safe_value)}", pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.05)), BLACK, screen, SCREEN_WIDTH - 300, 20)

    # Draw buttons
    deposit_money_button.draw(screen, BLACK)
    withdraw_money_button.draw(screen, BLACK)
    deposit_car_button.draw(screen, BLACK)
    withdraw_car_button.draw(screen, BLACK)
    sort_by_speed_button.draw(screen, BLACK)
    sort_by_price_button.draw(screen, BLACK)
    next_page_button.draw(screen, BLACK)
    prev_page_button.draw(screen, BLACK)
    back_button.draw(screen, BLACK)

    # Sort safe inventory based on criteria
    if sort_by_speed:
        sorted_safe_inventory = sorted(safe_inventory, key=lambda x: x[2], reverse=True)
    elif sort_by_price:
        sorted_safe_inventory = sorted(safe_inventory, key=lambda x: x[1], reverse=True)
    else:
        sorted_safe_inventory = safe_inventory

    # Display cars in safe
    start_y = 200
    page_safe_inventory = sorted_safe_inventory[safe_inventory_page * INVENTORY_SIZE_PER_PAGE:(safe_inventory_page + 1) * INVENTORY_SIZE_PER_PAGE]
    for index, (car_name, car_price, car_speed, car_rarity, neon, nitro) in enumerate(page_safe_inventory):
        rarity_color = RARITY_COLORS[car_rarity]
        prefix_color = None
        prefix = ""

        if neon and nitro:
            prefix_color = (NEON_GREEN, DARK_RED)
            prefix = "N"
        elif neon:
            prefix_color = (NEON_GREEN,)
            prefix = "N"
        elif nitro:
            prefix_color = (DARK_RED,)
            prefix = "N"

        draw_text(f"{index + 1}. {car_name} - ${format_money(car_price)}, Speed: {car_speed} mph", pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.03)), rarity_color, screen, 520, start_y)

        # Draw prefixes
        if prefix:
            for i, color in enumerate(prefix_color):
                draw_text(prefix, pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.03)), color, screen, 500 + i * 15, start_y)

        start_y += 18

    # Sort inventory for depositing
    if sort_by_speed:
        sorted_inventory = sorted(inventory, key=lambda x: x[2], reverse=True)
    elif sort_by_price:
        sorted_inventory = sorted(inventory, key=lambda x: x[1], reverse=True)
    else:
        sorted_inventory = inventory

    # Display cars in inventory for depositing
    start_y = 200
    page_inventory = sorted_inventory[inventory_page * INVENTORY_SIZE_PER_PAGE:(inventory_page + 1) * INVENTORY_SIZE_PER_PAGE]
    for index, (car_name, car_price, car_speed, car_rarity, neon, nitro) in enumerate(page_inventory):
        rarity_color = RARITY_COLORS[car_rarity]
        prefix_color = None
        prefix = ""

        if neon and nitro:
            prefix_color = (NEON_GREEN, DARK_RED)
            prefix = "N"
        elif neon:
            prefix_color = (NEON_GREEN,)
            prefix = "N"
        elif nitro:
            prefix_color = (DARK_RED,)
            prefix = "N"

        draw_text(f"{index + 1}. {car_name} - ${format_money(car_price)}, Speed: {car_speed} mph", pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.03)), rarity_color, screen, 30, start_y)

        # Draw prefixes
        if prefix:
            for i, color in enumerate(prefix_color):
                draw_text(prefix, pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.03)), color, screen, 10 + i * 15, start_y)

        start_y += 18

    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            if event.button == 1:  # Left click
                if deposit_money_button.is_over(pos):
                    if money > 0:
                        safe_money += money
                        money = 0
                elif withdraw_money_button.is_over(pos):
                    money += safe_money
                    safe_money = 0
                elif deposit_car_button.is_over(pos):
                    if selected_car and selected_car in inventory:
                        safe_inventory.append(selected_car)
                        inventory.remove(selected_car)
                        selected_car = None
                elif withdraw_car_button.is_over(pos):
                    if selected_car and selected_car in safe_inventory:
                        inventory.append(selected_car)
                        safe_inventory.remove(selected_car)
                        selected_car = None
                elif sort_by_speed_button.is_over(pos):
                    sort_by_speed = True
                    sort_by_price = False
                elif sort_by_price_button.is_over(pos):
                    sort_by_price = True
                    sort_by_speed = False
                elif next_page_button.is_over(pos):
                    if (safe_inventory_page + 1) * INVENTORY_SIZE_PER_PAGE < len(safe_inventory):
                        safe_inventory_page += 1
                    elif (inventory_page + 1) * INVENTORY_SIZE_PER_PAGE < len(inventory):
                        inventory_page += 1
                elif prev_page_button.is_over(pos):
                    if safe_inventory_page > 0:
                        safe_inventory_page -= 1
                    elif inventory_page > 0:
                        inventory_page -= 1
                elif back_button.is_over(pos):
                    current_screen = 'main_menu'
                    selected_car = None
                else:
                    for index, car in enumerate(page_inventory):
                        car_pos_y = 200 + index * 18
                        if 30 < pos[0] < 220 and car_pos_y < pos[1] < car_pos_y + 18:
                            selected_car = car
                            break
                    for index, car in enumerate(page_safe_inventory):
                        car_pos_y = 200 + index * 18
                        if SCREEN_WIDTH // 2 + 110 < pos[0] < SCREEN_WIDTH // 2 + 400 and car_pos_y < pos[1] < car_pos_y + 18:
                            selected_car = car
                            break

    # Draw box around selected car
    if selected_car:
        if selected_car in safe_inventory:
            car_index = safe_inventory.index(selected_car)
            x_pos = SCREEN_WIDTH // 2 + 110
        elif selected_car in inventory:
            car_index = inventory.index(selected_car)
            x_pos = 30
        else:
            car_index = -1

        if car_index != -1:
            y_pos = 200 + (car_index % INVENTORY_SIZE_PER_PAGE) * 18
            pygame.draw.rect(screen, BLACK, (x_pos, y_pos, 275, 18), 2)

    # Interest calculation
    interest_rate = calculate_interest_rate(safe_money)
    safe_money += safe_money * interest_rate / 60 / FPS

def car_index_screen():
    global current_screen, car_index_page
    screen.fill(WHITE)
    draw_text('Car Index', pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.1)), BLACK, screen, 20, 20)

    all_cars = [
        (car[0], car[3]) for rarity in CAR_RARITIES for car in CAR_DATA[rarity]
    ]

    cars_per_page = INVENTORY_SIZE_PER_PAGE * 2
    start_index = car_index_page * cars_per_page
    end_index = start_index + cars_per_page
    displayed_cars = all_cars[start_index:end_index]

    start_y = 80
    left_x = 20
    right_x = SCREEN_WIDTH // 2 + 20

    for index, (car_name, car_rarity) in enumerate(displayed_cars):
        x_pos = left_x if index % 2 == 0 else right_x
        y_pos = start_y + (index // 2) * 30
        # Check if car is owned
        car_color = GREEN if any(car_name == car[0] for car in inventory + safe_inventory) else RED
        draw_text(car_name, pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.03)), car_color, screen, x_pos, y_pos)

    next_page_button.draw(screen, BLACK)
    prev_page_button.draw(screen, BLACK)
    back_button.draw(screen, BLACK)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            if event.button == 1:
                if back_button.is_over(pos):
                    current_screen = 'main_menu'
                elif next_page_button.is_over(pos) and end_index < len(all_cars):
                    car_index_page += 1
                elif prev_page_button.is_over(pos) and car_index_page > 0:
                    car_index_page -= 1

def achievements_screen():
    global current_screen, achievement_page
    screen.fill(WHITE)
    draw_text('Achievements', pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.1)), BLACK, screen, 20, 20)

    start_y = 100
    achievements_per_page = ACHIEVEMENTS_PER_PAGE
    start_index = achievement_page * achievements_per_page
    end_index = start_index + achievements_per_page
    displayed_achievements = achievements[start_index:end_index]

    for achievement in displayed_achievements:
        name = achievement["name"]
        description = achievement["description"]
        completed = achievement["completed"]
        color = GREEN if completed else BLACK
        draw_text(f"{name} - {description}", pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.04)), color, screen, 20, start_y)
        start_y += 25

    next_page_button.draw(screen, BLACK)
    prev_page_button.draw(screen, BLACK)
    back_button.draw(screen, BLACK)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            if event.button == 1:
                if back_button.is_over(pos):
                    current_screen = 'main_menu'
                elif next_page_button.is_over(pos) and end_index < len(achievements):
                    achievement_page += 1
                elif prev_page_button.is_over(pos) and achievement_page > 0:
                    achievement_page -= 1

def list_car_screen():
    global current_screen, inventory_page, trade_offers
    screen.fill(WHITE)
    draw_text('List Car for Trade', pygame.font.SysFont(None, 50), BLACK, screen, 20, 20)

    back_button.draw(screen, BLACK)
    next_page_button.draw(screen, BLACK)
    prev_page_button.draw(screen, BLACK)

    start_y = 120
    cars_per_page = 10
    start_index = inventory_page * cars_per_page
    end_index = start_index + cars_per_page
    displayed_cars = inventory[start_index:end_index]

    for index, (car_name, car_price, car_speed, car_rarity, neon, nitro) in enumerate(displayed_cars):
        rarity_color = RARITY_COLORS[car_rarity]
        prefix_color = None
        prefix = ""

        if neon and nitro:
            prefix_color = (NEON_GREEN, DARK_RED)
            prefix = "N"
        elif neon:
            prefix_color = (NEON_GREEN,)
            prefix = "N"
        elif nitro:
            prefix_color = (DARK_RED,)
            prefix = "N"

        draw_text(f"{car_name} - ${format_money(car_price)}, Speed: {car_speed} mph", pygame.font.SysFont(None, 21), rarity_color, screen, 60, start_y)

        # Draw prefixes
        if prefix:
            for i, color in enumerate(prefix_color):
                draw_text(prefix, pygame.font.SysFont(None, 21), color, screen, 40 + i * 15, start_y)

        start_y += 21

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            if event.button == 1:
                if back_button.is_over(pos):
                    current_screen = 'main_menu'
                elif next_page_button.is_over(pos) and end_index < len(inventory):
                    inventory_page += 1
                elif prev_page_button.is_over(pos) and inventory_page > 0:
                    inventory_page -= 1
                else:
                    for car_index, car in enumerate(displayed_cars):
                        car_pos_y = 120 + car_index * 21
                        if 40 < pos[0] < SCREEN_WIDTH // 2 and car_pos_y < pos[1] < car_pos_y + 21:
                            trade_offer = {
                                'type': 'sell',
                                'car': car,
                                'price': car[1] * 1.5  # List car for 1.5 times its price
                            }
                            trade_offers.append(trade_offer)
                            inventory.remove(car)
                            print(f"Listed {car[0]} for ${format_money(trade_offer['price'])}")
                            break

def global_market_screen():
    global current_screen, market_page, money, inventory
    screen.fill(WHITE)
    draw_text('Global Market', pygame.font.SysFont(None, 50), BLACK, screen, 20, 20)

    back_button.draw(screen, BLACK)
    next_page_button.draw(screen, BLACK)
    prev_page_button.draw(screen, BLACK)

    start_y = 120
    offers_per_page = 10
    start_index = market_page * offers_per_page
    end_index = start_index + offers_per_page
    displayed_offers = trade_offers[start_index:end_index]

    for index, offer in enumerate(displayed_offers):
        offer_type = offer['type']
        car_name, car_price, car_speed, car_rarity, neon, nitro = offer['car']
        rarity_color = RARITY_COLORS[car_rarity]
        quality_color = evaluate_trade_quality(offer)

        offer_text = f"{car_name} - ${format_money(car_price)}, Speed: {car_speed} mph"
        if offer_type == 'sell':
            offer_text += f" - Selling for ${format_money(offer['price'])}"
        elif offer_type == 'trade':
            trade_for_name, trade_for_price, trade_for_speed, trade_for_rarity, trade_for_neon, trade_for_nitro = offer['trade_for']
            trade_for_text = f"{trade_for_name} - ${format_money(trade_for_price)}, Speed: {trade_for_speed} mph"
            offer_text += f" - Trading for {trade_for_text}"
        elif offer_type == 'trade_plus_money':
            trade_for_name, trade_for_price, trade_for_speed, trade_for_rarity, trade_for_neon, trade_for_nitro = offer['trade_for']
            trade_for_text = f"{trade_for_name} - ${format_money(trade_for_price)}, Speed: {trade_for_speed} mph"
            offer_text += f" - Trading for {trade_for_text} + ${format_money(offer['money'])}"
        elif offer_type == 'buy':
            offer_text += f" - Buying for ${format_money(offer['price'])}"

        draw_text(offer_text, pygame.font.SysFont(None, 21), quality_color, screen, 60, start_y)
        start_y += 21

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            if event.button == 1:
                if back_button.is_over(pos):
                    current_screen = 'main_menu'
                elif next_page_button.is_over(pos) and end_index < len(trade_offers):
                    market_page += 1
                elif prev_page_button.is_over(pos) and market_page > 0:
                    market_page -= 1
                else:
                    for offer_index, offer in enumerate(displayed_offers):
                        offer_pos_y = 120 + offer_index * 21
                        if 60 < pos[0] < SCREEN_WIDTH and offer_pos_y < pos[1] < offer_pos_y + 21:
                            if offer['type'] == 'sell':
                                if money >= offer['price']:
                                    money -= offer['price']
                                    inventory.append(offer['car'])
                                    trade_offers.remove(offer)
                                    print(f"Bought {offer['car'][0]} for ${format_money(offer['price'])}")
                            elif offer['type'] == 'buy':
                                car_to_sell = next((car for car in inventory if car[0] == offer['car'][0] and car[1] == offer['car'][1] and car[2] == offer['car'][2] and car[3] == offer['car'][3] and car[4] == offer['car'][4] and car[5] == offer['car'][5]), None)
                                if car_to_sell:
                                    money += offer['price']
                                    inventory.remove(car_to_sell)
                                    trade_offers.remove(offer)
                                    print(f"Sold {offer['car'][0]} for ${format_money(offer['price'])}")
                            elif offer['type'] == 'trade':
                                car_to_trade = next((car for car in inventory if car[0] == offer['trade_for'][0] and car[1] == offer['trade_for'][1] and car[2] == offer['trade_for'][2] and car[3] == offer['trade_for'][3] and car[4] == offer['trade_for'][4] and car[5] == offer['trade_for'][5]), None)
                                if car_to_trade:
                                    inventory.remove(car_to_trade)
                                    inventory.append(offer['car'])
                                    trade_offers.remove(offer)
                                    print(f"Traded {offer['trade_for'][0]} for {offer['car'][0]}")
                            elif offer['type'] == 'trade_plus_money':
                                if offer['money'] > 0:  # Trading car + money for another car
                                    car_to_trade = next((car for car in inventory if car[0] == offer['car'][0] and car[1] == offer['car'][1] and car[2] == offer['car'][2] and car[3] == offer['car'][3] and car[4] == offer['car'][4] and car[5] == offer['car'][5]), None)
                                    if car_to_trade and money >= offer['money']:
                                        money -= offer['money']
                                        inventory.remove(car_to_trade)
                                        inventory.append(offer['trade_for'])
                                        trade_offers.remove(offer)
                                        print(f"Traded {offer['car'][0]} + ${format_money(offer['money'])} for {offer['trade_for'][0]}")
                                else:  # Trading car for another car + money
                                    car_to_trade = next((car for car in inventory if car[0] == offer['trade_for'][0] and car[1] == offer['trade_for'][1] and car[2] == offer['trade_for'][2] and car[3] == offer['trade_for'][3] and car[4] == offer['trade_for'][4] and car[5] == offer['trade_for'][5]), None)
                                    if car_to_trade and money >= abs(offer['money']):
                                        money -= abs(offer['money'])
                                        inventory.remove(car_to_trade)
                                        inventory.append(offer['car'])
                                        trade_offers.remove(offer)
                                        print(f"Traded {offer['trade_for'][0]} for {offer['car'][0]} + ${format_money(offer['money'])}")
                            break

def coinflip_screen():
    global current_screen, selected_car, money, inventory_page  # Add inventory_page to global variables
    screen.fill(WHITE)
    draw_text('Coinflip', pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.1)), BLACK, screen, 20, 20)
    draw_text('Double or Nothing!', pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.05)), BLACK, screen, 20, 80)

    if selected_car:
        draw_text(f"Selected Car: {selected_car[0]}", pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.05)), BLACK, screen, 20, 140)
        flip_button = Button(GREEN, SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 - 50, 200, 100, 'Flip Coin')
        flip_button.draw(screen, BLACK)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if flip_button.is_over(pos):
                    if random.random() < 0.5:
                        # Win
                        money += selected_car[1]
                        print(f"You won! You doubled your car value. Money: ${format_money(money)}")
                    else:
                        # Lose
                        inventory.remove(selected_car)
                        print(f"You lost! You lost your car. Money: ${format_money(money)}")
                    selected_car = None
                    current_screen = 'main_menu'
    else:
        draw_text('Select a car from your inventory', pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.05)), BLACK, screen, 20, 140)

        start_y = 200
        cars_per_page = 10
        if 'inventory_page' not in globals():  # Initialize inventory_page if not already defined
            inventory_page = 0
        start_index = inventory_page * cars_per_page
        end_index = start_index + cars_per_page
        displayed_cars = inventory[start_index:end_index]

        car_rects = []
        for index, (car_name, car_price, car_speed, car_rarity, neon, nitro) in enumerate(displayed_cars):
            rarity_color = RARITY_COLORS[car_rarity]
            prefix_color = None
            prefix = ""

            if neon and nitro:
                prefix_color = (NEON_GREEN, DARK_RED)
                prefix = "N"
            elif neon:
                prefix_color = (NEON_GREEN,)
                prefix = "N"
            elif nitro:
                prefix_color = (DARK_RED,)
                prefix = "N"

            car_rect = pygame.Rect(40, start_y, SCREEN_WIDTH // 2, 21)  # Hitbox for the car name
            car_rects.append((car_rect, (car_name, car_price, car_speed, car_rarity, neon, nitro)))
            draw_text(f"{car_name} - ${format_money(car_price)}, Speed: {car_speed} mph", pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.03)), rarity_color, screen, 60, start_y)

            # Draw prefixes
            if prefix:
                for i, color in enumerate(prefix_color):
                    draw_text(prefix, pygame.font.SysFont(None, int(SCREEN_HEIGHT * 0.03)), color, screen, 40 + i * 15, start_y)

            start_y += 28

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if back_button.is_over(pos):
                    current_screen = 'main_menu'
                elif next_page_button.is_over(pos) and end_index < len(inventory):
                    inventory_page += 1
                elif prev_page_button.is_over(pos) and inventory_page > 0:
                    inventory_page -= 1
                else:
                    for car_rect, car in car_rects:
                        if car_rect.collidepoint(pos):
                            selected_car = car
                            break

    back_button.draw(screen, BLACK)
    next_page_button.draw(screen, BLACK)
    prev_page_button.draw(screen, BLACK)


# Main game loop
running = True
while running:
    if current_screen == 'main_menu':
        main_menu()
    elif current_screen == 'inventory':
        inventory_screen()
    elif current_screen == 'probability':
        probability_screen()
    elif current_screen == 'drag_race':
        drag_race_screen()
    elif current_screen == 'safe':
        safe_screen()
    elif current_screen == 'car_index':
        car_index_screen()
    elif current_screen == 'achievements':
        achievements_screen()
    elif current_screen == 'list_car':
        list_car_screen()
    elif current_screen == 'global_market':
        global_market_screen()
    elif current_screen == 'coinflip':
        coinflip_screen()

    pygame.display.update()
    clock.tick(FPS)
